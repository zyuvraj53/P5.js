System.register(["./chunk-vendor.js", "./chunk-frameworks.js"], (function() {
    "use strict";
    var e, t, o, n, a, i, c;
    return {
        setters: [function(o) {
            e = o.o, t = o.a
        }, function(e) {
            o = e.V, n = e.B, a = e.aw, i = e.x, c = e.q
        }],
        execute: function() {
            let r, l = !1;

            function s(e) {
                r = window.setTimeout(d, 5e3, e)
            }
            async function d(e) {
                const t = e.value,
                    n = e.getAttribute("data-url");
                await o();
                const a = await fetch(n, {
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    }
                });
                if (t === await a.text()) s(e);
                else if (!l) {
                    const e = document.querySelector("#gollum-editor-submit");
                    e instanceof HTMLButtonElement && (e.disabled = !0, document.querySelector("#gollum-error-message").classList.remove("d-none"))
                }
            }
            e("#wiki-current-version", {
                constructor: HTMLInputElement,
                initialize(e) {
                    s(e)
                },
                remove() {
                    clearTimeout(r)
                }
            }), t("click", "#gollum-editor-submit", (function() {
                l = !0
            }));
            const u = {
                node1: null,
                node2: null,
                selectNodeRange() {
                    const {
                        node1: e,
                        node2: t
                    } = u;
                    if (e && t) {
                        if (u.nodeComesAfter(e, t)) {
                            const e = u.node1;
                            u.node1 = u.node2, u.node2 = e
                        }
                        let o = e.nextElementSibling;
                        for (; o && o !== t;) o = o.nextElementSibling
                    }
                },
                nodeComesAfter(e, t) {
                    let o = e.previousElementSibling;
                    for (; o;) {
                        if (o === t) return !0;
                        o = o.previousElementSibling
                    }
                    return !1
                },
                checkNode(e) {
                    const t = e.closest(".js-wiki-history-revision");
                    e.checked ? u.node1 ? u.node2 ? e.checked = !1 : (u.node2 = t, u.selectNodeRange()) : u.node1 = t : u.node1 && t === u.node1 ? (u.node1 = null, u.node2 && (u.node1 = u.node2, u.node2 = null)) : u.node2 && t === u.node2 && (u.node2 = null)
                }
            };
            e(".js-wiki-history-checkbox", (function(e) {
                e instanceof HTMLInputElement && e.checked && u.checkNode(e)
            })), t("change", ".js-wiki-history-checkbox", (function({
                currentTarget: e
            }) {
                e instanceof HTMLInputElement && u.checkNode(e)
            })), n((function() {
                if (!document.querySelector("#wiki-wrapper")) return;
                const e = window.location.hash.match(/^#(wiki-(.+))$/);
                if (!e) return;
                const t = e[1],
                    o = e[2];
                a(document, t) || (window.location.hash = o)
            }));
            const p = {
                    markupCreated: !1,
                    markup: "",
                    attachEvents() {
                        document.querySelector("#gollum-dialog-action-ok").addEventListener("click", p.eventOK), document.querySelector("#gollum-dialog-action-cancel").addEventListener("click", p.eventCancel);
                        for (const e of document.querySelectorAll('#gollum-dialog-dialog input[type="text"]')) e.addEventListener("keydown", p.eventKeydown)
                    },
                    detachEvents() {
                        document.querySelector("#gollum-dialog-action-ok").removeEventListener("click", p.eventOK), document.querySelector("#gollum-dialog-action-cancel").removeEventListener("click", p.eventCancel)
                    },
                    createFieldMarkup(e) {
                        let t = "<fieldset>";
                        for (let o = 0; o < e.length; o++)
                            if ("object" == typeof e[o]) {
                                switch (t += "<div>", e[o].type) {
                                    case "text":
                                        t += p.createFieldText(e[o])
                                }
                                t += "</div>"
                            }
                        return t += "</fieldset>", t
                    },
                    createFieldText(e) {
                        let t = "";
                        return e.name && (t += '<label class="d-block mb-1"', e.id && (t += ` for="gollum-dialog-dialog-generated-field-${e.id}"`), t += `>${e.name}</label>`), t += '<input type="text" class="mb-3 input-block"', e.id && (t += ` name="${e.id}"`, t += ` id="gollum-dialog-dialog-generated-field-${e.id}">`), t
                    },
                    createMarkup: (e, t) => (p.markupCreated = !0, `\n      <div id="gollum-dialog-dialog">\n        <div class="Box-header">\n          <h3 class="Box-title">${e}</h3>\n        </div>\n        <div class="Box-body overflow-auto">\n          <div id="gollum-dialog-dialog-body">${t}</div>\n          <div id="gollum-dialog-dialog-buttons" class="pt-3 border-top">\n            <button type="button" id="gollum-dialog-action-cancel" class="ml-2 btn btn-sm btn-outline float-right" data-close-dialog>Cancel</a>\n            <button type="button" id="gollum-dialog-action-ok" class="btn btn-sm btn-outline float-right" data-close-dialog>OK</a>\n          </div>\n        </div>\n      </div>`),
                    eventCancel(e) {
                        e.preventDefault(), p.hide()
                    },
                    eventOK(e) {
                        e.preventDefault();
                        const t = {};
                        for (const o of document.querySelectorAll("#gollum-dialog-dialog-body input")) {
                            const e = o.getAttribute("name");
                            e && (t[e] = o.value)
                        }
                        p.getDetailsElement().addEventListener("toggle", (function() {
                            "function" == typeof p.okEventCallback && p.okEventCallback(t)
                        }), {
                            once: !0
                        }), p.hide()
                    },
                    eventKeydown(e) {
                        "Enter" === e.key && p.eventOK(e)
                    },
                    hide() {
                        p.markupCreated = !1, p.getDetailsElement().removeAttribute("open"), p.detachEvents()
                    },
                    getDetailsElement: () => document.querySelector(".js-gollum-button-details"),
                    init(e) {
                        let t = "",
                            o = "";
                        if (!e || "object" != typeof e) return;
                        e.body && "string" == typeof e.body && (o = `<p>${e.body}</p>`), e.fields && "object" == typeof e.fields && (o += p.createFieldMarkup(e.fields)), e.title && "string" == typeof e.title && (t = e.title), p.okEventCallback = e.OK, p.markup = p.createMarkup(t, o), p.show(), p.attachEvents();
                        const n = document.querySelector('#gollum-dialog-dialog input[type="text"]');
                        n instanceof HTMLInputElement && (n.autofocus = !0)
                    },
                    show() {
                        p.markupCreated && (document.querySelector(".js-gollum-button-dialog").innerHTML = p.markup, p.getDetailsElement().setAttribute("open", ""))
                    }
                },
                m = {
                    MarkupType: "markdown",
                    EditorMode: "code",
                    NewFile: !1,
                    HasFunctionBar: !0
                };
            let h = m;

            function g(e) {
                if (h = Object.assign(m, e), y.baseEditorMarkup() && y.functionBar()) {
                    const e = document.querySelector("#gollum-editor-body").getAttribute("data-markup-lang");
                    if (e && (h.MarkupType = e), y.formatSelector() && w.init(document.querySelector("#gollum-editor-format-selector select")), b.setActiveLanguage(h.MarkupType), y.help()) {
                        const e = document.getElementById("gollum-editor-help");
                        e && (e.style.display = "none", e.classList.remove("jaws"))
                    }
                }
            }

            function f(e, t) {
                "object" == typeof t && b.define(e, t)
            }
            const b = {
                    _ACTIVE_LANG: "",
                    _LOADED_LANGS: [],
                    _LANG: {},
                    define(e, t) {
                        if (b._ACTIVE_LANG = e, b._LOADED_LANGS.push(e), "object" == typeof g.WikiLanguage) {
                            const o = {};
                            Object.assign(o, g.WikiLanguage, t), b._LANG[e] = o
                        } else b._LANG[e] = t
                    },
                    getActiveLanguage: () => b._ACTIVE_LANG,
                    setActiveLanguage(e) {
                        if (b.getHookFunctionFor("deactivate")) {
                            const e = b.getHookFunctionFor("deactivate");
                            e && e()
                        }

                        function t() {
                            if (k.refresh(), b.isValid() && y.formatSelector() && w.updateSelected(), b.getHookFunctionFor("activate")) {
                                const e = b.getHookFunctionFor("activate");
                                e && e()
                            }
                        }
                        b.isLoadedFor(e) ? (b._ACTIVE_LANG = e, t()) : (b._ACTIVE_LANG = "", b.define(e, {}), t())
                    },
                    getHookFunctionFor(e, t) {
                        let o = t;
                        return o || (o = b._ACTIVE_LANG), b.isLoadedFor(o) && b._LANG[o][e] && "function" == typeof b._LANG[o][e] ? b._LANG[o][e] : null
                    },
                    getDefinitionFor(e, t) {
                        let o = t;
                        return o || (o = b._ACTIVE_LANG), b.isLoadedFor(o) && b._LANG[o][e] && "object" == typeof b._LANG[o][e] ? b._LANG[o][e] : null
                    },
                    isLoadedFor(e) {
                        if (0 === b._LOADED_LANGS.length) return !1;
                        for (let t = 0; t < b._LOADED_LANGS.length; t++)
                            if (b._LOADED_LANGS[t] === e) return !0;
                        return !1
                    },
                    isValid: () => b._ACTIVE_LANG && "object" == typeof b._LANG[b._ACTIVE_LANG]
                },
                y = {
                    baseEditorMarkup: () => null != document.querySelector("#gollum-editor") && null != document.querySelector("#gollum-editor-body"),
                    formatSelector: () => null != document.querySelector("#gollum-editor-format-selector select"),
                    functionBar: () => h.HasFunctionBar && null != document.querySelector("#gollum-editor-function-bar"),
                    ff4Environment: () => new RegExp(/Firefox\/4.0b/).test(navigator.userAgent),
                    editSummaryMarkup: () => null != document.querySelector("input#gollum-editor-message-field"),
                    help: () => null != document.querySelector("#gollum-editor #gollum-editor-help") && null != document.querySelector("#gollum-editor #function-help")
                },
                k = {
                    isActive: !1,
                    activate() {
                        const e = document.querySelector("#gollum-editor-function-bar");
                        for (const t of e.querySelectorAll(".function-button")) null != b.getDefinitionFor(t.id) ? (t.addEventListener("click", k.evtFunctionButtonClick), t.classList.remove("disabled")) : "function-help" !== t.id && (t.removeEventListener("click", k.evtFunctionButtonClick), t.classList.add("disabled"));
                        e.classList.add("active"), k.isActive = !0
                    },
                    deactivate() {
                        const e = document.querySelector("#gollum-editor-function-bar");
                        for (const t of e.querySelectorAll(".function-button")) t.removeEventListener("click", k.evtFunctionButtonClick);
                        e.classList.remove("active"), k.isActive = !1
                    },
                    evtFunctionButtonClick(e) {
                        const {
                            currentTarget: t
                        } = e;
                        e.preventDefault();
                        const o = b.getDefinitionFor(t.id);
                        "object" == typeof o && o && k.executeAction(o)
                    },
                    executeAction(e) {
                        const t = document.getElementById("gollum-editor-body"),
                            o = t.value,
                            n = k.getFieldSelection(t);
                        let a = "string" == typeof n ? n : "",
                            i = !0,
                            c = null;
                        if ("function" == typeof e.exec && "string" == typeof n) {
                            return void e.exec.call(e, o, n, t)
                        }
                        let r = /([^\n]+)/gi;
                        if (e.search && "object" == typeof e.search && (r = new RegExp(e.search)), e.replace && "string" == typeof e.replace) {
                            const t = e.replace;
                            a = a.replace(r, t), a = a.replace(/\$[\d]/g, ""), "" === a && (c = t.indexOf("$1"), a = t.replace(/\$[\d]/g, ""), -1 === c && (c = Math.floor(t.length / 2)))
                        }
                        e.append && "string" == typeof e.append && ("string" == typeof n && a === n && (i = !1), a += e.append), a && k.replaceFieldSelection(t, a, i, c)
                    },
                    getFieldSelectionPosition: e => ({
                        start: e.selectionStart,
                        end: e.selectionEnd
                    }),
                    getFieldSelection(e) {
                        const t = k.getFieldSelectionPosition(e);
                        return e.value.substring(t.start, t.end)
                    },
                    isShown() {
                        const e = document.querySelector("#gollum-editor-function-bar");
                        return null != e && i(e)
                    },
                    refresh() {
                        y.functionBar() && (b.isValid() ? (k.activate(), x && x.setActiveHelp(b.getActiveLanguage())) : (k.isShown() && k.deactivate(), x.isShown() && x.hide()))
                    },
                    replaceFieldSelection(e, t, o, n) {
                        const a = k.getFieldSelectionPosition(e),
                            i = e.value;
                        let c = !0;
                        !1 === o && (c = !1);
                        let r = null;
                        e.scrollTop && (r = e.scrollTop), e.value = i.substring(0, a.start) + t + i.substring(a.end), c && ("number" == typeof n && n > 0 ? e.setSelectionRange(a.start + n, a.start + n) : e.setSelectionRange(a.start, a.start + t.length)), e.focus(), r && (e.scrollTop = r)
                    }
                },
                w = {
                    SELECTOR: null,
                    evtChangeFormat() {
                        const e = this.value;
                        b.setActiveLanguage(e)
                    },
                    init(e) {
                        null != w.SELECTOR && w.SELECTOR.removeEventListener("change", w.evtChangeFormat), w.SELECTOR = e, w.updateSelected();
                        const t = w.SELECTOR;
                        t && t.addEventListener("change", w.evtChangeFormat)
                    },
                    updateSelected() {
                        const e = b.getActiveLanguage(),
                            t = w.SELECTOR;
                        t && (t.value = e)
                    }
                },
                x = {
                    _ACTIVE_HELP: "",
                    _ACTIVE_HELP_LANG: "",
                    _LOADED_HELP_LANGS: [],
                    _HELP: {},
                    define(e, t) {
                        const o = document.querySelector("#function-help");
                        if (x.isValidHelpFormat(t)) {
                            if (x._ACTIVE_HELP_LANG = e, x._LOADED_HELP_LANGS.push(e), x._HELP[e] = t, o) {
                                o.classList.remove("disabled"), o.addEventListener("click", x.evtHelpButtonClick), x.generateHelpMenuFor(e);
                                const t = document.querySelector("#gollum-editor-help");
                                t && t.hasAttribute("data-autodisplay") && x.show()
                            }
                        } else o && (o.classList.add("disabled"), o.removeEventListener("click", x.evtHelpButtonClick))
                    },
                    clickFirstHelpLink() {
                        const e = document.querySelector("#gollum-editor-help-list .menu-item");
                        e && e.click()
                    },
                    generateHelpMenuFor(e) {
                        if (!x._HELP[e]) return !1;
                        const t = x._HELP[e],
                            o = document.querySelector("#gollum-editor-help-parent");
                        o.innerHTML = "", document.querySelector("#gollum-editor-help-list").innerHTML = "", document.querySelector("#gollum-editor-help-content").innerHTML = "";
                        for (let n = 0; n < t.length && "object" == typeof t[n]; n++) {
                            const e = c(document, `<a href="#" rel="${n}" class="menu-item border-bottom">${t[n].menuName}</a>`),
                                a = e.querySelector("a");
                            0 === n && a.classList.add("selected"), a.addEventListener("click", x.evtParentMenuClick), o.append(e)
                        }
                        x.generateSubMenu(t[0], 0), x.clickFirstHelpLink()
                    },
                    generateSubMenu(e, t) {
                        const o = document.querySelector("#gollum-editor-help-list");
                        o.innerHTML = "", document.querySelector("#gollum-editor-help-content").innerHTML = "";
                        for (let n = 0; n < e.content.length && "object" == typeof e.content[n]; n++) {
                            const a = c(document, `<a href="#" rel="${t}:${n}" class="menu-item border-bottom">${e.content[n].menuName}</a>`);
                            for (const e of a.querySelectorAll("a")) e.addEventListener("click", x.evtSubMenuClick);
                            o.append(a)
                        }
                    },
                    hide() {
                        const e = document.querySelector("#gollum-editor-help");
                        e && (e.style.display = "none")
                    },
                    show() {
                        const e = document.querySelector("#gollum-editor-help");
                        e && (e.style.display = "")
                    },
                    showHelpFor(e, t) {
                        const o = x._HELP[x._ACTIVE_HELP_LANG][e].content[t].data;
                        document.querySelector("#gollum-editor-help-content").innerHTML = o
                    },
                    isLoadedFor(e) {
                        for (let t = 0; t < x._LOADED_HELP_LANGS.length; t++)
                            if (e === x._LOADED_HELP_LANGS[t]) return !0;
                        return !1
                    },
                    isShown() {
                        const e = document.querySelector("#gollum-editor-help");
                        return null != e && i(e)
                    },
                    isValidHelpFormat: e => !("object" != typeof e || !e.length || "string" != typeof e[0].menuName || "object" != typeof e[0].content || !e[0].content.length),
                    setActiveHelp(e) {
                        const t = document.querySelector("#function-help");
                        x.isLoadedFor(e) ? (x._ACTIVE_HELP_LANG = e, t && (t.classList.remove("disabled"), t.addEventListener("click", x.evtHelpButtonClick), x.generateHelpMenuFor(e))) : (t && (t.classList.add("disabled"), t.removeEventListener("click", x.evtHelpButtonClick)), x.isShown() && x.hide())
                    },
                    evtHelpButtonClick(e) {
                        const {
                            currentTarget: t
                        } = e;
                        if (e.preventDefault(), x.isShown()) {
                            const e = document.querySelector("#gollum-editor-help");
                            if (e.hasAttribute("data-autodisplay")) {
                                const o = t.getAttribute("data-dismiss-help-url"),
                                    n = t.parentElement.querySelector(".js-data-dismiss-help-url-csrf"),
                                    a = new URLSearchParams;
                                fetch(o, {
                                    method: "delete",
                                    mode: "same-origin",
                                    body: a,
                                    headers: {
                                        "Scoped-CSRF-Token": n.value,
                                        "X-Requested-With": "XMLHttpRequest"
                                    }
                                }), e.removeAttribute("data-autodisplay")
                            }
                            x.hide()
                        } else x.show()
                    },
                    evtParentMenuClick(e) {
                        e.preventDefault();
                        const {
                            currentTarget: t
                        } = e;
                        if (t.classList.contains("selected")) return;
                        const o = t.rel,
                            n = x._HELP[x._ACTIVE_HELP_LANG][o];
                        for (const a of document.querySelectorAll("#gollum-editor-help-parent .menu-item")) a.classList.remove("selected");
                        t.classList.add("selected"), x.generateSubMenu(n, o), x.clickFirstHelpLink()
                    },
                    evtSubMenuClick(e) {
                        e.preventDefault();
                        const {
                            currentTarget: t
                        } = e;
                        if (t.classList.contains("selected")) return;
                        const o = t.rel.split(":");
                        for (const n of document.querySelectorAll("#gollum-editor-help-list .menu-item")) n.classList.remove("selected");
                        t.classList.add("selected"), x.showHelpFor(o[0], o[1])
                    }
                },
                L = x.define;

            function v(e) {
                const t = document.querySelector("#gollum-editor-body");
                k.replaceFieldSelection(t, e)
            }
            const T = {
                    "function-bold": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "*$1*$2"
                    },
                    "function-italic": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "_$1_$2"
                    },
                    "function-code": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "+$1+$2"
                    },
                    "function-ul": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "* $1$2"
                    },
                    "function-ol": {
                        search: /(.+)([\n]?)/g,
                        replace: ". $1$2"
                    },
                    "function-blockquote": {
                        search: /(.+)([\n]?)/g,
                        replace: "----\n$1$2\n----\n"
                    },
                    "function-link": {
                        exec() {
                            p.init({
                                title: "Insert Link",
                                fields: [{
                                    id: "text",
                                    name: "Link Text",
                                    type: "text",
                                    help: "The text to display to the user."
                                }, {
                                    id: "href",
                                    name: "URL",
                                    type: "text",
                                    help: "The URL to link to."
                                }],
                                OK(e) {
                                    let t = "";
                                    e.text && e.href && (t = `${e.href}[${e.text}]`), v(t)
                                }
                            })
                        }
                    },
                    "function-image": {
                        exec() {
                            p.init({
                                title: "Insert Image",
                                fields: [{
                                    id: "url",
                                    name: "Image URL",
                                    type: "text"
                                }, {
                                    id: "alt",
                                    name: "Alt Text",
                                    type: "text"
                                }],
                                OK(e) {
                                    let t = "";
                                    e.url && e.alt && (t = `image::${e.url}[${e.alt}]`), v(t)
                                }
                            })
                        }
                    }
                },
                E = {
                    "function-bold": {
                        search: /([^\n]+)([\n\s]*)/g,
                        replace: "**$1**$2"
                    },
                    "function-italic": {
                        search: /([^\n]+)([\n\s]*)/g,
                        replace: "_$1_$2"
                    },
                    "function-code": {
                        search: /([^\n]+)([\n\s]*)/g,
                        replace: "`$1`$2"
                    },
                    "function-hr": {
                        append: "\n***\n"
                    },
                    "function-ul": {
                        search: /(.+)([\n]?)/g,
                        replace: "* $1$2"
                    },
                    "function-ol": {
                        search: /(.+)([\n]?)/g,
                        replace: "1. $1$2"
                    },
                    "function-blockquote": {
                        search: /(.+)([\n]?)/g,
                        replace: "> $1$2"
                    },
                    "function-h1": {
                        search: /(.+)([\n]?)/g,
                        replace: "# $1$2"
                    },
                    "function-h2": {
                        search: /(.+)([\n]?)/g,
                        replace: "## $1$2"
                    },
                    "function-h3": {
                        search: /(.+)([\n]?)/g,
                        replace: "### $1$2"
                    },
                    "function-link": {
                        exec() {
                            p.init({
                                title: "Insert Link",
                                fields: [{
                                    id: "text",
                                    name: "Link Text",
                                    type: "text"
                                }, {
                                    id: "href",
                                    name: "URL",
                                    type: "text"
                                }],
                                OK(e) {
                                    let t = "";
                                    e.text && e.href && (t = `[${e.text}](${e.href})`), v(t)
                                }
                            })
                        }
                    },
                    "function-image": {
                        exec() {
                            p.init({
                                title: "Insert Image",
                                fields: [{
                                    id: "url",
                                    name: "Image URL",
                                    type: "text"
                                }, {
                                    id: "alt",
                                    name: "Alt Text",
                                    type: "text"
                                }],
                                OK(e) {
                                    let t = "";
                                    e.url && (t = `![${e.alt}](${e.url})`), v(t)
                                }
                            })
                        }
                    }
                },
                $ = {
                    "function-bold": {
                        search: /([^\n]+)([\n\s]*)/g,
                        replace: "*$1*$2"
                    },
                    "function-italic": {
                        search: /([^\n]+)([\n\s]*)/g,
                        replace: "/$1/$2"
                    },
                    "function-code": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "=$1=$2"
                    },
                    "function-ul": {
                        search: /(.+)([\n]?)/g,
                        replace: "* $1$2"
                    },
                    "function-ol": {
                        search: /(.+)([\n]?)/g,
                        replace: "1. $1$2"
                    },
                    "function-blockquote": {
                        search: /(.+)([\n]?)/g,
                        replace: "#+BEGIN_QUOTE\n$1$2\n#+END_QUOTE\n"
                    },
                    "function-h1": {
                        search: /(.+)([\n]?)/g,
                        replace: "* $1$2"
                    },
                    "function-h2": {
                        search: /(.+)([\n]?)/g,
                        replace: "** $1$2"
                    },
                    "function-h3": {
                        search: /(.+)([\n]?)/g,
                        replace: "*** $1$2"
                    },
                    "function-link": {
                        exec() {
                            p.init({
                                title: "Insert Link",
                                fields: [{
                                    id: "text",
                                    name: "Link Text",
                                    type: "text"
                                }, {
                                    id: "href",
                                    name: "URL",
                                    type: "text"
                                }],
                                OK(e) {
                                    let t = "";
                                    e.text && e.href ? t = `[[${e.href}][${e.text}]]` : e.href && (t = `[[${e.href}]]`), v(t)
                                }
                            })
                        }
                    },
                    "function-image": {
                        exec() {
                            p.init({
                                title: "Insert Image",
                                fields: [{
                                    id: "url",
                                    name: "Image URL",
                                    type: "text"
                                }],
                                OK(e) {
                                    let t = "";
                                    e.url && (t = `[[${e.url}]]`), v(t)
                                }
                            })
                        }
                    }
                },
                S = {
                    "function-bold": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "B<$1>$2"
                    },
                    "function-italic": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "I<$1>$2"
                    },
                    "function-code": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "C<$1>$2"
                    },
                    "function-h1": {
                        search: /(.+)([\n]?)/gi,
                        replace: "=head1 $1$2"
                    },
                    "function-h2": {
                        search: /(.+)([\n]?)/gi,
                        replace: "=head2 $1$2"
                    },
                    "function-h3": {
                        search: /(.+)([\n]?)/gi,
                        replace: "=head3 $1$2"
                    },
                    "function-link": {
                        exec() {
                            p.init({
                                title: "Insert Link",
                                fields: [{
                                    id: "text",
                                    name: "Link Text",
                                    type: "text"
                                }, {
                                    id: "href",
                                    name: "URL",
                                    type: "text"
                                }],
                                OK(e) {
                                    let t = "";
                                    e.text && e.href && (t = `L<${e.text}|${e.href}>`), v(t)
                                }
                            })
                        }
                    }
                },
                N = {
                    "function-bold": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "*$1*$2"
                    },
                    "function-italic": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "_$1_$2"
                    },
                    "function-hr": {
                        append: "\n***\n"
                    },
                    "function-code": {
                        search: /(^[\n]+)([\n\s]*)/g,
                        replace: "<pre><code>$1</code></pre>$2"
                    },
                    "function-ul": {
                        search: /(.+)([\n]?)/gi,
                        replace: "* $1$2"
                    },
                    "function-ol": {
                        search: /(.+)([\n]?)/gi,
                        replace: "# $1$2"
                    },
                    "function-blockquote": {
                        search: /(.+)([\n]?)/gi,
                        replace: "bq. $1$2"
                    },
                    "function-link": {
                        exec() {
                            p.init({
                                title: "Insert Link",
                                fields: [{
                                    id: "text",
                                    name: "Link Text",
                                    type: "text",
                                    help: "The text to display to the user."
                                }, {
                                    id: "href",
                                    name: "URL",
                                    type: "text",
                                    help: "The URL to link to."
                                }],
                                OK(e) {
                                    let t = "";
                                    e.text && e.href && (t = `"${e.text}":${e.href}`), v(t)
                                }
                            })
                        }
                    },
                    "function-image": {
                        exec() {
                            p.init({
                                title: "Insert Image",
                                fields: [{
                                    id: "url",
                                    name: "Image URL",
                                    type: "text"
                                }, {
                                    id: "alt",
                                    name: "Alt Text",
                                    type: "text"
                                }],
                                OK(e) {
                                    if (e.url) {
                                        let t = "!" + e.url;
                                        "" !== e.alt && (t += `(${e.alt})`), t += "!", v(t)
                                    }
                                }
                            })
                        }
                    }
                },
                A = {
                    "function-bold": {
                        search: /([^\n]+)([\n]*)/gi,
                        replace: "**$1**$2"
                    },
                    "function-italic": {
                        search: /([^\n]+)([\n]*)/gi,
                        replace: "//$1//$2"
                    },
                    "function-code": {
                        search: /([^\n]+)([\n]*)/gi,
                        replace: "{{{$1}}}$2"
                    },
                    "function-hr": {
                        append: "\n\n----\n\n"
                    },
                    "function-ul": {
                        search: /(.+)([\n]?)/gi,
                        replace: "* $1$2"
                    },
                    "function-ol": {
                        search: /(.+)([\n]?)/gi,
                        replace: "# $1$2"
                    },
                    "function-link": {
                        exec() {
                            p.init({
                                title: "Insert Link",
                                fields: [{
                                    id: "text",
                                    name: "Link Text",
                                    type: "text",
                                    help: "The text to display to the user."
                                }, {
                                    id: "href",
                                    name: "URL",
                                    type: "text",
                                    help: "The URL to link to."
                                }],
                                OK(e) {
                                    v(`[[${e.href}|${e.text}]]`)
                                }
                            })
                        }
                    },
                    "function-image": {
                        exec() {
                            p.init({
                                title: "Insert Image",
                                fields: [{
                                    id: "url",
                                    name: "Image URL",
                                    type: "text"
                                }, {
                                    id: "alt",
                                    name: "Alt Text",
                                    type: "text"
                                }],
                                OK(e) {
                                    let t = "";
                                    e.url && e.alt && (t = "{{" + e.url, "" !== e.alt && (t += `|${e.alt}}}`)), v(t)
                                }
                            })
                        }
                    }
                },
                _ = {
                    "function-bold": {
                        search: /([^\n]+)([\n\s]*)/g,
                        replace: "((*$1*))$2"
                    },
                    "function-code": {
                        search: /([^\n]+)([\n\s]*)/g,
                        replace: "(({$1}))$2"
                    },
                    "function-ul": {
                        search: /(.+)([\n]?)/gi,
                        replace: "* $1$2"
                    },
                    "function-ol": {
                        exec(e, t) {
                            let o = "";
                            const n = t.split("\n"),
                                a = /[\w]+/;
                            for (let i = 0; i < n.length; i++) a.test(n[i]) && (o += `(${(i+1).toString()}) ${n[i]}`);
                            v(o)
                        }
                    },
                    "function-h1": {
                        search: /(.+)([\n]?)/gi,
                        replace: "= $1$2"
                    },
                    "function-h2": {
                        search: /(.+)([\n]?)/gi,
                        replace: "== $1$2"
                    },
                    "function-h3": {
                        search: /(.+)([\n]?)/gi,
                        replace: "=== $1$2"
                    }
                };
            e("#gollum-editor", (function(e) {
                g({
                    NewFile: e.classList.contains("create")
                })
            })), g.WikiLanguage = {
                "function-internal-link": {
                    exec: () => p.init({
                        title: "Insert Wiki Link",
                        fields: [{
                            id: "name",
                            name: "Link Name",
                            type: "text"
                        }],
                        OK: e => v(e.name ? `[[${e.name}]]` : "")
                    })
                }
            }, t("click", ".js-wiki-toggle-collapse", (function(e) {
                const t = e.currentTarget.closest(".js-wiki-pages-box");
                for (const o of t.querySelectorAll(".js-wiki-sidebar-toggle-display")) o.classList.toggle("d-none")
            })), t("click", ".js-wiki-more-pages-link", (function(e) {
                e.preventDefault(), e.currentTarget.closest(".js-wiki-pages-box").classList.toggle("wiki-show-more")
            })), t("preview:setup", ".js-previewable-comment-form", (function(e) {
                const t = e.currentTarget.querySelector("#wiki_format");
                if (t) {
                    e.detail.data.append("wiki_format", t.value)
                }
            })), t("change", "#wiki_format", (function(e) {
                const t = e.currentTarget.closest(".js-previewable-comment-form");
                t.classList.contains("preview-selected") && t.dispatchEvent(new CustomEvent("preview:render", {
                    bubbles: !0,
                    cancelable: !1
                }))
            })), L("asciidoc", [{
                menuName: "Text Formatting",
                content: [{
                    menuName: "Headers",
                    data: "<p>ASCIIDoc headers can be written in two ways: with differing underlines or with different indentation using <code>=</code> (equals sign). ASCIIDoc supports headings 1-4. The editor will automatically use the <code>=</code> notation. To create a level one header, prefix your line with one <code>=</code>. Level two headers are created with <code>==</code> and so on.</p>"
                }, {
                    menuName: "Bold / Italic",
                    data: "<p>To display text as <strong>bold</strong>, wrap the text in <code>*</code> (asterisks). To display text as <em>italic</em>, wrap the text in <code>_</code> (underscores). To create <code>monospace</code> text, wrap the text in <code>+</code> (plus signs)."
                }, {
                    menuName: "Scripts",
                    data: "<p>Superscript and subscript is created the same way as other inline formats. To create superscript text, wrap your text in <code>^</code> (carats). To create subscript text, wrap your text in <code>~</code> (tildes).</p>"
                }, {
                    menuName: "Special Characters",
                    data: "<p>ASCIIDoc will automatically convert textual representations of commonly-used special characters. For example, <code>(R)</code> becomes &reg;, <code>(C)</code> becomes &copy; and <code>(TM)</code> becomes &trade;.</p>"
                }]
            }, {
                menuName: "Blocks",
                content: [{
                    menuName: "Paragraphs",
                    data: "<p>ASCIIDoc allows paragraphs to have optional titles or icons to denote special sections. To make a normal paragraph, simply add a line between blocks and a new paragraph will start. If you want to title your paragraphs, adda line prefixed by <code>.</code> (full stop). An example paragraph with optional title is displayed below:<br><br><code>.Optional Title<br><br>This is my paragraph. It is two sentences long.</code></p>"
                }, {
                    menuName: "Source Blocks",
                    data: "<p>To create source blocks (long blocks of code), follow the same syntax as above but with an extra line denoting the inline source and lines of four dashes (<code>----</code>) delimiting the source block.. An example of Python source is below:<br><br><code>.python.py<br>[source,python]<br>----<br># i just wrote a comment in python<br># and maybe one more<br>----</code></p>"
                }, {
                    menuName: "Comment Blocks",
                    data: "<p>Comment blocks are useful if you want to keep notes for yourself inline but do not want them displayed to the public. To create a comment block, simply wrap the paragraph in dividers with four slashes (<code>////</code>). An example comment block is below:<br><br><code>////<br>My comment block is here now<br><br>It can be multiple paragraphs. Really.<br>////</p>"
                }, {
                    menuName: "Quote Blocks",
                    data: "<p>Quote blocks work much like comment blocks &mdash; simply create dividers using four underscores (<code>____</code>) around your quote. An example quote block is displayed below:<br><code>____<br>This is my quote block. Quote something nice here, otherwise there is no point in quoting.<br>____</code></p>"
                }]
            }, {
                menuName: "Macros",
                content: [{
                    menuName: "Links",
                    data: '<p>To create links to external pages, you can simply write the URI if you want the URI to link to itself. (i.e., <code>https://github.com/</code> will automatically be parsed to <a href="javascript:void(0);">https://github.com/</a>. If you want different text to be displayed, simply append it to the end of the URI in between <code>[</code> (brackets.) For example, <code>https://github.com/[GitHub]</code> will be parsed as <a href="javascript:void(0);">GitHub</a>, with the URI pointing to <code>https://github.com</code>.</p>'
                }, {
                    menuName: "Images",
                    data: "<p>Images in ASCIIDoc work much like hyperlinks, but image URLs are prefixed with <code>image:</code>. For example, to link to an image at <code>images/icons/home.png</code>, write <code>image:images/icons/home.png</code>. Alt text can be added by appending the text to the URI in <code>[</code> (brackets).</p>"
                }]
            }]), L("markdown", [{
                menuName: "Block Elements",
                content: [{
                    menuName: "Paragraphs &amp; Breaks",
                    data: "<p>To create a paragraph, simply create a block of text that is not separated by one or more blank lines. Blocks of text separated by one or more blank lines will be parsed as paragraphs.</p><p>If you want to create a line break, end a line with two or more spaces, then hit Return/Enter.</p>"
                }, {
                    menuName: "Headers",
                    data: "<p>Markdown supports two header formats. The wiki editor uses the &ldquo;atx&rdquo;-style headers. Simply prefix your header text with the number of <code>#</code> characters to specify heading depth. For example: <code># Header 1</code>, <code>## Header 2</code> and <code>### Header 3</code> will be progressively smaller headers. You may end your headers with any number of hashes.</p>"
                }, {
                    menuName: "Blockquotes",
                    data: "<p>Markdown creates blockquotes email-style by prefixing each line with the <code>&gt;</code>. This looks best if you decide to hard-wrap text and prefix each line with a <code>&gt;</code> character, but Markdown supports just putting <code>&gt;</code> before your paragraph.</p>"
                }, {
                    menuName: "Lists",
                    data: "<p>Markdown supports both ordered and unordered lists. To create an ordered list, simply prefix each line with a number (any number will do &mdash; this is why the editor only uses one number.) To create an unordered list, you can prefix each line with <code>*</code>, <code>+</code> or <code>-</code>.</p> List items can contain multiple paragraphs, however each paragraph must be indented by at least 4 spaces or a tab."
                }, {
                    menuName: "Code Blocks",
                    data: "<p>Markdown wraps code blocks in pre-formatted tags to preserve indentation in your code blocks. To create a code block, indent the entire block by at least 4 spaces or one tab. Markdown will strip the extra indentation you’ve added to the code block.</p>"
                }, {
                    menuName: "Horizontal Rules",
                    data: "Horizontal rules are created by placing three or more hyphens, asterisks or underscores on a line by themselves. Spaces are allowed between the hyphens, asterisks or underscores."
                }]
            }, {
                menuName: "Span Elements",
                content: [{
                    menuName: "Links",
                    data: "<p>Markdown has two types of links: <strong>inline</strong> and <strong>reference</strong>. For both types of links, the text you want to display to the user is placed in square brackets. For example, if you want your link to display the text &ldquo;GitHub&rdquo;, you write <code>[GitHub]</code>.</p><p>To create an inline link, create a set of parentheses immediately after the brackets and write your URL within the parentheses. (e.g., <code>[GitHub](https://github.com/)</code>). Relative paths are allowed in inline links.</p><p>To create a reference link, use two sets of square brackets. <code>[[my internal link|internal-ref]]</code> will link to the internal reference <code>internal-ref</code>.</p>"
                }, {
                    menuName: "Emphasis",
                    data: "<p>Asterisks (<code>*</code>) and underscores (<code>_</code>) are treated as emphasis and are wrapped with an <code>&lt;em&gt;</code> tag, which usually displays as italics in most browsers. Double asterisks (<code>**</code>) or double underscores (<code>__</code>) are treated as bold using the <code>&lt;strong&gt;</code> tag. To create italic or bold text, simply wrap your words in single/double asterisks/underscores. For example, <code>**My double emphasis text**</code> becomes <strong>My double emphasis text</strong>, and <code>*My single emphasis text*</code> becomes <em>My single emphasis text</em>.</p>"
                }, {
                    menuName: "Code",
                    data: "<p>To create inline spans of code, simply wrap the code in backticks (<code>`</code>). Markdown will turn <code>`myFunction`</code> into <code>myFunction</code>.</p>"
                }, {
                    menuName: "Images",
                    data: "<p>Markdown image syntax looks a lot like the syntax for links; it is essentially the same syntax preceded by an exclamation point (<code>!</code>). For example, if you want to link to an image at <code>https://github.com/unicorn.png</code> with the alternate text <code>My Unicorn</code>, you would write <code>![My Unicorn](https://github.com/unicorn.png)</code>.</p>"
                }]
            }, {
                menuName: "Miscellaneous",
                content: [{
                    menuName: "Automatic Links",
                    data: '<p>If you want to create a link that displays the actual URL, markdown allows you to quickly wrap the URL in <code>&lt;</code> and <code>&gt;</code> to do so. For example, the link <a href="javascript:void(0);">https://github.com/</a> is easily produced by writing <code>&lt;https://github.com/&gt;</code>.</p>'
                }, {
                    menuName: "Escaping",
                    data: "<p>If you want to use a special Markdown character in your document (such as displaying literal asterisks), you can escape the character with the backslash (<code>\\</code>). Markdown will ignore the character directly after a backslash."
                }]
            }]), L("org", [{
                menuName: "Block Elements",
                content: [{
                    menuName: "Paragraphs &amp; Breaks",
                    data: "<p>To create a paragraph, simply create a block of text that is not separated by one or more blank lines. Blocks of text separated by one or more blank lines will be parsed as paragraphs.</p>"
                }, {
                    menuName: "Headers",
                    data: "<p>Simply prefix your header text with the number of <code>*</code> characters to specify heading depth. For example: <code>* Header 1</code>, <code>** Header 2</code> and <code>*** Header 3</code> will be progressively smaller headers.</p>"
                }, {
                    menuName: "Blockquotes",
                    data: "<p>To create a blockquote, simple embed the text between <code>#+BEGIN_QUOTE</code> and <code>#+END_QUOTE</code>. An example quote block is displayed below:<br><code>#+BEGIN_QUOTE<br>This is my quote block. Quote something nice here, otherwise there is no point in quoting.<br>#+END_QUOTE</code></p>"
                }, {
                    menuName: "Lists",
                    data: "<p>Org-mode supports both ordered and unordered lists. To create an ordered list, simply prefix each line with a number (any number will do &mdash; this is why the editor only uses one number.) To create an unordered list, you can prefix each line with <code>+</code> or <code>-</code>.</p>"
                }, {
                    menuName: "Code Blocks",
                    data: "<p>Code Blocks are similar to blockquote, except that <code>#+BEGIN_EXAMPLE</code> and <code>#+END_EXAMPLE</code> are used.</p>"
                }, {
                    menuName: "Tables",
                    data: "<p>Org-mode supports simple tables (tables with equal number of cells in each row). To create a simple table, just separate the contents of each cell with a <code>|</code> character. For example, <br><br><code>|one|two|three|<br>|four|five|six|</code><br><br> will appear as a table with two rows and three columns.  Additionally, <br><br><code>|one|two|three|<br>|---+---+-----|<br>|four|five|six|</code><br><br> will also appear as a table, but the first row will be interpreted as a header row and the <code>&lt;th&gt;</code> tag will be used to render it. </p>"
                }]
            }, {
                menuName: "Span Elements",
                content: [{
                    menuName: "Links",
                    data: '<p>To create links to external pages, you need to enclose the URI in double square brackets. (i.e., <code>[[https://github.com/]]</code> will automatically be parsed to <a href="javascript:void(0);">https://github.com/</a>)If you want to add text, to be displayed to the user, you write the URI and the text next to each other, both enclosed in square brackets and both of them together enclosed in another pair of square brackets. For example, if you want your link to display the text &ldquo;GitHub&rdquo;, you write <code>[[https://github.com][GitHub]]</code>.</p>'
                }, {
                    menuName: "Emphasis",
                    data: "<p>Forward slashes (<code>/</code>) are treated as emphasis and are wrapped with an <code>&lt;i&gt;</code> tag. Asterisks (<code>*</code>) are treated as bold using the <code>&lt;b&gt;</code> tag.</p>"
                }, {
                    menuName: "Code",
                    data: "<p>To create inline spans of code, simply wrap the code in equal signs (<code>=</code>). Orgmode will turn <code>=myFunction=</code> into <code>myFunction</code>.</p>"
                }, {
                    menuName: "Images",
                    data: "<p>Org-mode image syntax is exactly same as the syntax that you would use for a URI to link to itself. The image URI is enclosed in double square brackets. Alt text on images is not currently supported by Gollum's Org-mode parser.</p>"
                }]
            }]), L("pod", [{
                menuName: "Command Paragraphs",
                content: [{
                    menuName: "Headings",
                    data: "<p>All command paragraphs start with <code>=</code> (equals sign).</p><p>To create headings 1 through 4, begin your command paragraph with <code>=headN</code>, where <code>N</code> is the number of the heading 1 through 4. For example, to make a first-order heading (the largest possible,) write <code>=head1</code>, then on the next line begin your paragraph that you want under the heading.</p>"
                }, {
                    menuName: "Beginning &amp; Ending",
                    data: "<p>Perl pod blocks should begin with <code>=pod</code> and end with <code>=cut</code>, signifying to Pod parsers that the pod block has begun and ended. These command paragraphs only signal the beginning and end of a pod block.</p>"
                }, {
                    menuName: "Other Formats",
                    data: "<p>pod also allows blocks in other formats, such as HTML or plain text. To create one of these blocks, use the <code>=format SYNTAX</code> command paragraph, where <code>SYNTAX</code> is the syntax of the block (e.g. <code>html</code> or <code>txt</code>). At the end of your block, use the <code>=end SYNTAX</code> block.</p>"
                }, {
                    menuName: "Encoding",
                    data: "<p>If you are having encoding troubles, use the <code>=encoding ENC_TYPE</code> command, where <code>ENC_TYPE</code> is the encoding type (e.g. <code>utf8</code>, <code>koi8-r</code>). This will affect the entire document, not just the block below the command.</p>"
                }]
            }, {
                menuName: "Formatting",
                content: [{
                    menuName: "Text",
                    data: "<p>Formatting text as <strong>bold</strong>, <em>italic</em> or <code>code</code> works in the <code>S&lt;word&gt;</code> syntax, where <code>S</code> is an abbreviation for the type of text you are trying to create. For example, <code>B&lt;my bold text&gt;</code> becomes <strong>my bold text</strong>,  <code>I&lt;italic text&gt;</code> becomes <em>italic text</em> and <code>C&lt;code here()&gt;</code> becomes <code>code here()</code>.</p>"
                }, {
                    menuName: "Hyperlinks",
                    data: "<p>Writing hyperlinks in pod is much like formatting text, using the same <code>S&lt;&gt;</code> syntax. Instead of <code>B</code>, <code>I</code> or <code>C</code>, use <code>L</code> to begin a hyperlink.</p><p>pod allows you to hyperlink to a <code>man</code> page, a Perl documentation page, or another web page. To link to a <code>man</code> or Perl documentation page, simply include the page name in the link (e.g. <code>L&lt;perl(1)&gt;</code> or <code>L&lt;Net::Ping&gt;</code>). If you want to link to a web page, separate the URL and the link text with a pipe (e.g. to link to github.com, write <code>L&lt;GitHub|https://github.com/&gt;</code>)."
                }]
            }]), L("textile", [{
                menuName: "Phrase Modifiers",
                content: [{
                    menuName: "Emphasis / Strength",
                    data: "<p>To place emphasis or strength on inline text, simply place <code>_</code> (underscores) around the text for emphasis or <code>*</code> (asterisks) around the text for strength. In most browsers, <code>_mytext_</code> will appear as italics and <code>*mytext*</code> will appear as bold.</p><p>To force italics or bold, simply double the characters: <code>__mytext__</code> will appear italic and <code>**mytext**</code> will appear as bold text.</p>"
                }, {
                    menuName: "Citations / Editing",
                    data: '<p>To display citations, wrap your text in <code>??</code> (two question marks).</p><p>To display edit marks such as deleted text (strikethrough) or inserted text (underlined text), wrap your text in <code>-</code> (minuses) or <code>+</code> (pluses). For example <code>-mytext-</code> will be rendered as <span style="text-decoration: line-through;">mytext</span> and <code>+mytext+</code> will be rendered as <span style="text-decoration: underline;">mytext</span></p>'
                }, {
                    menuName: "Superscript / Subscript",
                    data: "<p>To display superscript, wrap your text in <code>^</code> (carets). To display subscript, wrap your text in <code>~</code> (tildes).</p>"
                }, {
                    menuName: "Code",
                    data: "<p>To display monospace code, wrap your text in <code>@</code> (at symbol). For example, <code>@mytext@</code> will appear as <code>mytext</code>.</p>"
                }, {
                    menuName: "Acronyms",
                    data: '<p>To create an acronym, suffix the acronym with the definition in parentheses. For example, <code>JS(JavaScript)</code> will be displayed as <abbr title="JavaScript">JS</abbr>.</p>'
                }]
            }, {
                menuName: "Block Modifiers",
                content: [{
                    menuName: "Headings",
                    data: "<p>To display a heading in Textile, prefix your line of text with <code>hn.</code>, where <code>n</code> equals the heading size you want (1 is largest, 6 is smallest).</p>"
                }, {
                    menuName: "Paragraphs / Quotes",
                    data: "<p>To create a new paragraph, prefix your first line of a block of text with <code>p.</code>.</p><p>To create a blockquote, make sure at least one blank line exists between your text and any surrounding text, and then prefix that block with <code>bq.</code> If you need to extend a blockquote to more than one text block, write <code>bq..</code> (note the two periods) and prefix your next normal paragraph with <code>p.</code></p>"
                }, {
                    menuName: "Code Blocks",
                    data: "<p>Code blocks in textile are simply prefixed like any other block. To create a code block, place the beginning of the block on a separate line and prefix it with <code>bc.</code></p><p>To display a preformatted block, prefix the block with <code>pre.</code></p>"
                }, {
                    menuName: "Lists",
                    data: "<p>To create ordered lists, prefix each line with <code>#</code>. To create unordered lists, prefix each line with <code>*</code>.</p>"
                }]
            }, {
                menuName: "Links / Images",
                content: [{
                    menuName: "Links",
                    data: '<p>To display a link, put the text you want to display in quotes, then a colon (<code>:</code>), then the URL after the colon. For example <code>&quot;GitHub&quot;:https://github.com/</code> will appear as <a href="javascript:void(0);">GitHub</a>.</p>'
                }, {
                    menuName: "Images",
                    data: "<p>To display an image, simply wrap the image’s URL in <code>!</code> (exclamation points). If you want to link the image to a URL, you can blend the image and link syntax: place your image URL in the exclamation points and suffix that with a colon and your URL. For example, an image at <code>http://myurl/image.png</code> that should link to <code>http://myurl/</code> should be written as <code>!http://myurl/image.png!:http://myurl/</code>.</p>"
                }]
            }]), f("asciidoc", T), f("creole", A), f("markdown", E), f("org", $), f("pod", S), f("rdoc", _), f("textile", N)
        }
    }
}));
//# sourceMappingURL=wiki-683449c1.js.map